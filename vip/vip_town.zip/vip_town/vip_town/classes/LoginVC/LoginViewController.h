//
//  LoginViewController.h
//  vip_town
//
//  Created by yanbo on 15/6/11.
//  Copyright (c) 2015年 vip. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController
/**
 *  电话
 */
@property (weak, nonatomic) IBOutlet UITextField *phone;

/**
 *  密码
 */
@property (weak, nonatomic) IBOutlet UITextField *password;




@end
