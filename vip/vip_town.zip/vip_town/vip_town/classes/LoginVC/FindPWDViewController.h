//
//  FindPWDViewController.h
//  vip_town
//
//  Created by yanbo on 15/6/16.
//  Copyright (c) 2015年 vip. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FindPWDViewController : UIViewController

@end
