//
//  CustomTabBar.m
//  vip_town
//
//  Created by 王旭 on 15/5/19.
//  Copyright (c) 2015年 vip. All rights reserved.
//

#import "CustomTabBar.h"
#import "ContactUsViewController.h"
#import "HomePageViewController.h"
#import "ShoppingCartViewController.h"
#import "UserCenterViewController.h"
#import "CurseNavigation.h"
@interface CustomTabBar ()
{
    UIImageView *bgImageView;
}
@end

@implementation CustomTabBar


- (void)viewDidLoad {
    [super viewDidLoad];
    [self customTabBar];
    // Do any additional setup after loading the view.
}

-(void)customTabBar {
    
    DEFINE_CONTROLLER(HomePageViewController, homeNvc);
    
    DEFINE_CONTROLLER(ShoppingCartViewController, shopCartNvc);
    
    DEFINE_CONTROLLER(UserCenterViewController, userNvc);
    
    DEFINE_CONTROLLER(ContactUsViewController, contactNvc);
    
    self.viewControllers = @[homeNvc, shopCartNvc, userNvc, contactNvc];
    [self UIConfig];
}

-(void)UIConfig {
    //自定义一个UITabBar步骤
    //1.隐藏系统自带的UITabBar
    self.tabBar.hidden = YES;
    //2.根据产品需求添加tabbar的背景图片
    bgImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, kSCREENH - 49, kSCREENW, 49)];
    bgImageView.image = [UIImage imageNamed:@"tabbg.png"];
    bgImageView.backgroundColor = KRGBA(100, 100, 100, 1);
    bgImageView.userInteractionEnabled = YES;
    [self.view addSubview:bgImageView];
    NSArray * titleArray = [NSArray arrayWithObjects:@"首    页", @"购  物  车", @"个人中心", @"联系我们", nil];
    //3.根据产品需求在背景图片上添加按钮
    for (int i  = 0; i < 4; i ++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake((kSCREENW/4) * i, 0, kSCREENW/4, 49);
        btn.titleLabel.font = [UIFont systemFontOfSize:14];
        [btn setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%d.png",i+1]] forState:UIControlStateNormal];
        [btn setImageEdgeInsets:UIEdgeInsetsMake(0, ((kSCREENW/4)-20)/2 - 7, 19, 0)];
        
        [btn setTitle:[titleArray objectAtIndex:i] forState:UIControlStateNormal];
        [btn setTitleEdgeInsets:UIEdgeInsetsMake(30, -20, 0, 0)];
        
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        
        btn.tag = 100+i;
        [btn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        if (btn.tag == 100) {
            btn.selected = YES;
            btn.userInteractionEnabled = NO;
            
        }
        [bgImageView addSubview:btn];
    }
}

-(void)buttonClick:(UIButton *)btn {
    [self selectedIndex:btn.tag - 100];
}

-(void)selectedIndex:(NSInteger)index {
    //4.点击不同的按钮，切换不同的视图控制器
    self.selectedIndex = index;
    
    for (UIView  *view in bgImageView.subviews){
        //判断view是否是UIButton类型
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)view;
            if((index + 100) == button.tag)
            {
                button.selected = YES;
                button.userInteractionEnabled = NO;
                button.backgroundColor = [UIColor colorWithRed:70/255.f green:70/255.f blue:70/255.f alpha:1.f];
            } else {
                button.selected = NO;
                button.userInteractionEnabled = YES;
                button.backgroundColor = [UIColor clearColor];
            }
        }
    }
}

-(void)hiddenTabBar {
    bgImageView.hidden = YES;
}

-(void)appearTabBar {
    bgImageView.hidden = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
