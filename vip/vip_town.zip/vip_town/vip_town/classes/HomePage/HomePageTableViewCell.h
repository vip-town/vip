//
//  HomePageTableViewCell.h
//  vip_town
//
//  Created by 小小旭 on 15/6/2.
//  Copyright (c) 2015年 vip. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomePageTableViewCell : UITableViewCell

@end
