//
//  ShoppingViewController.h
//  vip_town
//
//  Created by 王旭 on 15/6/7.
//  Copyright (c) 2015年 vip. All rights reserved.
//

#import "BaseViewController.h"

@interface ShoppingViewController : BaseViewController

@property (nonatomic, assign)NSInteger type;

@end
