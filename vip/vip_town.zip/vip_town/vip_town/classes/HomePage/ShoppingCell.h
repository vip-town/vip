//
//  ShoppingCell.h
//  vip_town
//
//  Created by 王旭 on 15/6/8.
//  Copyright (c) 2015年 vip. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShoppingCell : UITableViewCell

@end
