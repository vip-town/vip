//
//  HomePageTableViewCell.m
//  vip_town
//
//  Created by 小小旭 on 15/6/2.
//  Copyright (c) 2015年 vip. All rights reserved.
//

#import "HomePageTableViewCell.h"

@implementation HomePageTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
