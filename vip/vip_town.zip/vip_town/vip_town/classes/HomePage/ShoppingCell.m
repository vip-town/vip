//
//  ShoppingCell.m
//  vip_town
//
//  Created by 王旭 on 15/6/8.
//  Copyright (c) 2015年 vip. All rights reserved.
//

#import "ShoppingCell.h"

@implementation ShoppingCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
