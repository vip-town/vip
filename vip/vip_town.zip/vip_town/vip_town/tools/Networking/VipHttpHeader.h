//
//  VipHttpHeader.h
//  vip_town
//
//  Created by yanbo on 15/5/26.
//  Copyright (c) 2015年 vip. All rights reserved.
//

#ifndef vip_town_VipHttpHeader_h
#define vip_town_VipHttpHeader_h
#define APP_BASE_URL @""





#endif
